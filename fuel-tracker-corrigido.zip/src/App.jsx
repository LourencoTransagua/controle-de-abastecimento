import { useState, useEffect } from "react";

export default function App() {
  const [entries, setEntries] = useState([]);
  const [form, setForm] = useState({
    vehicle: "",
    date: "",
    liters: "",
    km: "",
    fuel: "",
  });
  const [vehicleFilter, setVehicleFilter] = useState("");

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem("fuel_entries")) || [];
    setEntries(stored);
  }, []);

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    const newEntries = [...entries, form];
    localStorage.setItem("fuel_entries", JSON.stringify(newEntries));
    setEntries(newEntries);
    setForm({ vehicle: "", date: "", liters: "", km: "", fuel: "" });
  };

  const filteredEntries = vehicleFilter
    ? entries.filter((e) => e.vehicle === vehicleFilter)
    : entries;

  const vehicles = [...new Set(entries.map((e) => e.vehicle))];

  const calcAvgPerEntry = () => {
    return filteredEntries.map((e, i) => {
      if (i === 0) return null;
      const prev = filteredEntries[i - 1];
      const kmDiff = parseFloat(e.km) - parseFloat(prev.km);
      const liters = parseFloat(e.liters);
      return liters > 0 ? (kmDiff / liters).toFixed(2) : null;
    }).filter(avg => avg !== null);
  };

  const calcMonthlyAvg = () => {
    const byMonth = {};
    filteredEntries.forEach(e => {
      const month = e.date.slice(0, 7);
      if (!byMonth[month]) byMonth[month] = [];
      byMonth[month].push(e);
    });

    const result = [];
    for (const month in byMonth) {
      const sorted = byMonth[month].sort((a, b) => new Date(a.date) - new Date(b.date));
      const first = sorted[0];
      const last = sorted[sorted.length - 1];
      const kmDriven = parseFloat(last.km) - parseFloat(first.km);
      const litersUsed = sorted.reduce((sum, e) => sum + parseFloat(e.liters), 0);
      const avg = litersUsed > 0 ? (kmDriven / litersUsed).toFixed(2) : "-";
      result.push({ month, avg });
    }
    return result;
  };

  return (
    <div className="max-w-3xl mx-auto p-4 space-y-6">
      <h1 className="text-3xl font-bold">Controle de Abastecimento</h1>

      <form onSubmit={handleSubmit} className="grid grid-cols-2 gap-4">
        {["vehicle", "date", "liters", "km", "fuel"].map((field) => (
          <input
            key={field}
            type={field === "date" ? "date" : "text"}
            name={field}
            placeholder={field}
            value={form[field]}
            onChange={handleChange}
            className="border p-2 rounded"
          />
        ))}
        <button type="submit" className="col-span-2 bg-blue-600 text-white py-2 rounded">Salvar</button>
      </form>

      <div>
        <label className="block mb-2 font-semibold">Filtrar por veículo:</label>
        <select
          value={vehicleFilter}
          onChange={(e) => setVehicleFilter(e.target.value)}
          className="border p-2 rounded w-full"
        >
          <option value="">Todos</option>
          {vehicles.map((v, idx) => (
            <option key={idx} value={v}>{v}</option>
          ))}
        </select>
      </div>

      <div className="space-y-4">
        <div className="bg-gray-100 p-4 rounded">
          <h2 className="font-semibold">Média por abastecimento</h2>
          {calcAvgPerEntry().map((avg, idx) => (
            <p key={idx}>Abastecimento #{idx + 1}: {avg} km/l</p>
          ))}
        </div>

        <div className="bg-gray-100 p-4 rounded">
          <h2 className="font-semibold">Média mensal por veículo</h2>
          {calcMonthlyAvg().map(({ month, avg }, idx) => (
            <p key={idx}>{month}: {avg} km/l</p>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        {filteredEntries.map((entry, idx) => (
          <div key={idx} className="bg-white shadow p-4 rounded border">
            <p><strong>Veículo:</strong> {entry.vehicle}</p>
            <p><strong>Data:</strong> {entry.date}</p>
            <p><strong>Litros:</strong> {entry.liters}</p>
            <p><strong>Preço:</strong> R$ {(parseFloat(entry.liters) * 5.28).toFixed(2)}</p>
            <p><strong>KM:</strong> {entry.km}</p>
            <p><strong>Combustível:</strong> {entry.fuel}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
